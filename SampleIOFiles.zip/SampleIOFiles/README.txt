inputA.txt => outputA.txt
inputB.txt => outputB.txt

Make sure that your output matches the files exactly :)
